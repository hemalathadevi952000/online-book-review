package com.service; 

 

import org.springframework.beans.factory.annotation.Autowired; 

import org.springframework.stereotype.Service; 

 

import com.entity.Admin; 

import com.repo.AdminRepo; 

 

@Service 

public class AdminService { 

@Autowired 

AdminRepo adminRepo; 

 

public boolean addAdmin(Admin admin) 

{ 

int c = adminRepo.hasAdmin(admin.getEmail()); 

if(c>0) 

{ 

return false; 

}else 

{ 

adminRepo.save(admin); 

return true; 

} 

} 
public boolean updateAdmin(Admin admin) 

{ 

if(adminRepo.save(admin) != null) { 

return true; 

}else { 

return false; 

} 

} 

 

public boolean validateAdmin(String email, String pass) 

{ 

if(adminRepo.validateLogin(email, pass) != null) 

{ 

return true; 

}else 

{ 

return false; 

} 

} 

} 