package com.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.User;
import com.service.UserService;

@RestController
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/addUser")
    public ResponseEntity<Boolean> addUser(@RequestBody User user) {
        try {
            boolean isAdded = userService.addUser(user);
            return ResponseEntity.ok(isAdded);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
        }
    }

    @GetMapping("/getUser/{email}")
    public ResponseEntity<Optional<User>> getUser(@PathVariable("email") String email) {
        try {
            Optional<User> user = userService.getUser(email);
            if (user.isPresent()) {
                return ResponseEntity.ok(user);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/validUserLogin/{email}/{password}")
    public ResponseEntity<Boolean> validateUser(@PathVariable("email") String email, @PathVariable("password") String pass) {
        try {
            boolean isValid = userService.validateUser(email, pass);
            return ResponseEntity.ok(isValid);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
        }
    }

    @PutMapping("/updateUser")
    public ResponseEntity<Boolean> updateUser(@RequestBody User user) {
        try {
            boolean isUpdated = userService.updateUser(user);
            return ResponseEntity.ok(isUpdated);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
        }
    }
}
